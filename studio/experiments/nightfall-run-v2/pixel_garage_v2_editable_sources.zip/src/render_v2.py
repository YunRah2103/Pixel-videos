#!/usr/bin/env python3
"""V2 sprite animation: same inherited V1 scene architecture, upgraded car/forest, no cropped second shot.
10.000s/300 frames/30fps/360x640 native -> integer 3x FFmpeg. Independent parallax speeds and physically coupled wheel travel.
"""
from PIL import Image, ImageDraw
from pathlib import Path
import os,math,subprocess,argparse
ROOT=Path(__file__).resolve().parents[1]; ASSETS=ROOT/'assets';W,H,FPS=360,640,30
NAMES=['01_sky','01b_sky_details','02_far_mountains','02b_far_details','03_mid_forest','04_near_trees','06_road','05_guardrail','07_foreground']
L={p.stem:Image.open(p).convert('RGBA') for p in ASSETS.glob('*.png')}
assert all(n in L for n in [*NAMES,'08_car_body','09_wheel','10_car_fenders'])
BODY=L['08_car_body']; WHEEL=L['09_wheel']; FENDERS=L['10_car_fenders']
# Original wheel drawing has 5 asymmetric spokes with radial travel coupled to road rate.
WHEELS=[WHEEL.rotate(a,resample=Image.Resampling.NEAREST,expand=False) for a in range(0,360,5)]
# ensure native pixel palette/ramp; never bilinear or Gaussian effects

def displacement(t):
 # Start at 110px/sec, accelerate up to 300px/sec over 10s.
 return 110*t + 9.5*t*t

def tile(canvas,asset,xoff):
 w=asset.width; offset=round(xoff)%w
 for x in range(-offset,W,w):canvas.paste(asset,(x,0),asset)

def make_frame(f):
 t=f/FPS
 d=displacement(t)
 base=Image.new('RGBA',(W,H),'#0e132b')
 # Farscroll near zero, road and reflector poles >300px/sec in late shot.
 layer_parallax=[.004,.008,.045,.05,.18,.39,1.,.96,1.25]
 for i,(name,m) in enumerate(zip(NAMES,layer_parallax)):
  if name=='07_foreground':continue
  tile(base,L[name],(138+43*i) + d*m)
 # two deliberate framing compositions: scenic tracking 0..164; full-car road-side shot 165..299
 if f<165:
  scale=.908
  car_x=32+int(1.5*math.sin(t*.8))
 else:
  scale=.985
  car_x=17+int(1*math.sin(t*.7))
 # actual suspension: small horizontal vibration, sprung body; axles stay anchored near road
 road_impulse=math.sin(t*12.7)*.8+math.sin(t*20.2)*.42
 body_bounce=round(road_impulse)
 # car wheel centre remains at 526, road starts at 521
 car_y=round(524 - 135*scale) + body_bounce
 if scale!=1:
  b=BODY.resize((round(326*scale),round(176*scale)),Image.Resampling.NEAREST)
  fen=FENDERS.resize(b.size,Image.Resampling.NEAREST)
 else:b=BODY;fen=FENDERS
 draw=ImageDraw.Draw(base)
 # road contact shadow follows independent subject x and its wheelbase, no glowy fake motion
 rad=round(31*scale); left=car_x+round(79*scale); right=car_x+round(260*scale)
 draw.polygon([(left-34,526),(right+35,525),(right+45,539),(left-43,541)],fill='#101b2a')
 # wheel sidewalls anchored to actual rolling road. body is subtly pitched, not a static car silhouette.
 base.paste(b,(car_x,car_y),b)
 # For positive rightward car movement over leftward road, wheel spin clockwise as in side view.
 angle=(math.degrees(d/31.0)+20)%360
 idx=round(angle/5)%72
 wheel=WHEELS[idx]
 ww=round(68*scale)
 if ww!=68: wheel=wheel.resize((ww,ww),Image.Resampling.NEAREST)
 for cx in (79,260):
  ax=car_x+round((cx-34)*scale);ay=car_y+round((135-34)*scale)
  base.paste(wheel,(ax,ay),wheel)
 base.paste(fen,(car_x,car_y),fen)
 # crossing objects move fastest, an actual foreground layer
 tile(base,L['07_foreground'],(110+d*1.28))
 return base.convert('RGB')

def main():
 p=argparse.ArgumentParser();p.add_argument('--stills-only',action='store_true');p.add_argument('--output',default=str(ROOT/'nightfall_run_v2_10s.mp4'));a=p.parse_args()
 (ROOT/'stills').mkdir(exist_ok=True)
 for f in [0,40,85,132,163,165,185,240,290,299]:
  make_frame(f).resize((1080,1920),Image.Resampling.NEAREST).save(ROOT/'stills'/f'v2_frame_{f:03d}.png')
 print('10 native-pixel key frames written',flush=True)
 if a.stills_only:return
 args=['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pixel_format','rgb24','-video_size',f'{W}x{H}','-framerate','30','-i','pipe:0','-vf','scale=1080:1920:flags=neighbor,format=yuv420p','-c:v','libx264','-preset','veryfast','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart','-an','-frames:v','300',a.output]
 proc=subprocess.Popen(args,stdin=subprocess.PIPE)
 for f in range(300):
  try:proc.stdin.write(make_frame(f).tobytes())
  except BrokenPipeError:break
  if f%60==0:print('frame',f,flush=True)
 proc.stdin.close();rc=proc.wait()
 if rc:raise RuntimeError(f'FFmpeg render failed {rc}')
 print('Created',a.output,flush=True)
if __name__=='__main__':main()
