#!/usr/bin/env python3
"""Nightfall Run V2: editable original pixel-locked SVG layers; extends V1 composition.
Every primitive is intentionally pixel-snapped; deterministic repeatable art. No borrowed game assets.
"""
import random, math
from pathlib import Path
DIR=Path(__file__).resolve().parent/'svg';DIR.mkdir(exist_ok=True)
class Canvas:
 def __init__(self,w,h):
  self.a=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}" shape-rendering="crispEdges">']
 def r(self,x,y,w,h,c):
  if w>0 and h>0:self.a.append(f'<rect x="{int(x)}" y="{int(y)}" width="{int(w)}" height="{int(h)}" fill="{c}"/>')
 def p(self,pts,c):self.a.append('<polygon points="'+' '.join(f'{int(x)},{int(y)}' for x,y in pts)+'" fill="'+c+'"/>')
 def ellipse(self,x,y,rx,ry,c):
  pts=[(x+int(rx*math.cos(a*math.pi/18)),y+int(ry*math.sin(a*math.pi/18))) for a in range(36)]
  self.p(pts,c)
 def line(self,x1,y1,x2,y2,c,w=1):
  # only axis-aligned pixel runs
  if y1==y2:self.r(min(x1,x2),y1,abs(x2-x1)+1,w,c)
  if x1==x2:self.r(x1,min(y1,y2),w,abs(y2-y1)+1,c)
 def save(self,name):self.a.append('</svg>');(DIR/name).write_text('\n'.join(self.a))

r=random.Random(61126)
# extra high-altitude clouds and a strong painterly sunset focal point layered on top of retained V1 sky
s=Canvas(960,640)
# stout cloud clusters: purposeful stepped edges; not washed-out gradient or filters
for x,y,w,kind in [(62,215,115,0),(264,259,100,1),(514,177,121,2),(723,251,146,1),(859,172,83,0)]:
 cc=['#86505f','#a86465','#65425c'][kind]; bright=['#b27276','#db8a79','#a46c77'][kind]
 s.p([(x,y+14),(x+8,y+14),(x+8,y+8),(x+24,y+8),(x+24,y+3),(x+44,y+3),(x+44,y),(x+69,y),(x+69,y+3),(x+w-21,y+3),(x+w-21,y+8),(x+w-5,y+8),(x+w-5,y+14),(x+w,y+14),(x+w,y+19),(x+12,y+19),(x+12,y+17),(x,y+17)],cc)
 s.r(x+15,y+15,w-41,2,bright);s.r(x+34,y+2,25,2,bright);s.r(x+59,y+5,11,1,'#e6a287')
# crystalline clouds flanking the horizon
for i in range(36):
 x=(i*137+51)%960;y=190+(i*17%92)
 if i%3==0:s.r(x,y,15,2,'#ae6770')
 elif i%3==1:s.r(x,y,7,1,'#d28b7c')
# original design sun disc 1x raster step patches, not gaussian filter
cx,cy=388,293
for rad,col in [(36,'#e59a76'),(31,'#f7bc87'),(25,'#ffce92'),(17,'#ffe0a1')]:
 for yy in range(-rad,rad+1,2):
  xx=int(math.sqrt(max(0,rad*rad-yy*yy)))
  s.r(cx-xx,cy+yy,2*xx+1,2,col)
s.r(cx-26,cy+10,55,4,'#e8a781');s.r(cx-18,cy+17,37,2,'#e99c79')
# thin distant cirrus, bird group and tiny stair-step horizon accents
for x,y in [(440,329),(465,326),(500,334),(616,304),(651,315),(802,320)]:s.r(x,y,27,2,'#e7a27a')
for x,y in [(231,261),(240,256),(250,259)]:s.p([(x,y),(x+4,y+2),(x+8,y),(x+4,y+3)],'#3a3348')
s.save('01b_sky_details.svg')

# mountains/village silhouette detail; inherited V1 far mountain visible beneath
s=Canvas(960,640)
for x,y in [(42,370),(104,380),(235,377),(320,390),(422,368),(508,392),(666,377),(810,389),(905,379)]:
 s.p([(x,y+30),(x+11,y+18),(x+19,y+20),(x+30,y+8),(x+46,y+23),(x+59,y+18),(x+83,y+33),(x+83,440),(x,440)],'#695a75')
 s.r(x+25,y+15,13,2,'#c08c8a')
# scarce houses and embankment windows for lived-in distance
for x,y in [(76,408),(112,413),(303,408),(381,411),(559,410),(694,412),(861,412)]:
 s.r(x,y,20,12,'#343b56');s.p([(x-3,y),(x+10,y-9),(x+23,y)],'#59475f')
 s.r(x+5,y+3,4,3,'#e6ad81');s.r(x+13,y+3,4,3,'#d28d76')
s.save('02b_far_details.svg')

# VARIED MIDGROUND TREES, arranged as little authored groups with different heights/branches
s=Canvas(960,640)
s.p([(0,431),(34,423),(60,427),(89,413),(114,423),(161,415),(202,428),(246,416),(296,423),(337,410),(377,421),(425,411),(468,423),(512,410),(548,419),(603,408),(649,418),(693,410),(742,420),(786,408),(834,424),(885,408),(927,419),(960,409),(960,525),(0,525)],'#34445e')
def pine(s,x,base,h,w,seed,fg=False):
 rr=random.Random(seed); trunk='#253747' if fg else '#354255'
 s.r(x-3,base-h+15,6,base-(base-h+15),trunk)
 # multiple angular needle fans, unequal left/right, holes and clusters
 sections=6 if h>95 else 5
 for i in range(sections):
  cy=base-h+15+i*(h-28)//sections
  half=int(w*(.25+.115*i));left=half+rr.randrange(-5,4);right=half+rr.randrange(-3,7)
  dark=('#163a42' if fg else '#293e52');mid=['#24525a','#265761','#2b515c','#284b59'][i%4] if fg else ['#3a5667','#3b586a','#334f64','#35576b'][i%4]
  s.p([(x,cy-12),(x-left//2,cy+2),(x-left,cy+14),(x-11,cy+14),(x-14,cy+19),(x+right,cy+17),(x+right//2,cy+3)],dark)
  s.p([(x,cy-10),(x-left//2,cy+1),(x-left+6,cy+10),(x-8,cy+11),(x+right-8,cy+13),(x+right//2,cy+3)],mid)
  # careful lichen-like light clusters towards right sunlight face
  for q in range(2):
   dx=rr.randrange(-max(2,half-6),max(4,half-1));dy=rr.randrange(6,15)
   s.r(x+dx,cy+dy,rr.randrange(3,7),2,'#62827b' if fg else '#697c81')
  if i>1:
   s.r(x-left+2,cy+14,6,2,'#172f3c' if fg else '#273d51')
 s.r(x-2,base-5,5,11,'#1d303c' if fg else '#304155')
for i,(x,base,h,w) in enumerate([(14,432,86,37),(75,432,111,44),(122,424,68,30),(167,431,105,44),(208,426,75,36),(265,426,115,41),(314,429,83,37),(370,426,121,49),(422,436,72,38),(484,426,112,45),(531,430,87,36),(583,426,108,45),(633,428,69,37),(685,434,126,44),(739,427,89,38),(793,430,113,45),(847,431,76,35),(898,427,124,47),(951,431,89,40)]):
 pine(s,x,base,h,w,30+i)
# road beyond with tree-shadows parallax separations
s.r(0,444,960,4,'#3a5264')
for x in [18,89,138,254,310,439,540,616,714,812,899]:s.r(x,443,21,1,'#81918a')
s.save('03_mid_forest.svg')

# NEAR FOREST: individually silhouetted spruces and several deciduous trees with varied canopies
s=Canvas(960,640)
s.p([(0,486),(32,473),(60,479),(89,461),(131,478),(160,462),(201,483),(240,467),(287,472),(332,459),(380,481),(415,460),(461,478),(513,456),(554,478),(605,466),(649,477),(700,462),(747,480),(807,461),(858,472),(913,462),(960,480),(960,545),(0,545)],'#1a3944')
for i,(x,base,h,w) in enumerate([(17,490,125,45),(166,493,140,50),(345,485,120,43),(502,491,150,54),(673,483,119,43),(811,485,145,52),(923,488,131,49)]):pine(s,x,base,h,w,61+i,True)
# broad irregular sugar maple crowns: draw silhouette at native scale with distinct 2-3px cut-outs
canopies=[(96,457,0),(265,455,1),(427,451,2),(590,465,3),(755,461,4),(877,448,5)]
canopy_colors=[['#733e51','#9a4d56','#bd6259','#e48b65','#f2aa75'],['#703a4b','#a24f53','#cd6855','#e38b64','#f9b278'],['#4b4857','#825065','#a45d61','#d98570','#eba27c'],['#6a4050','#9d5062','#b85c5d','#ed9266','#f6b17a'],['#5f4054','#995362','#c46d65','#e78f69','#f3ac7c'],['#684354','#a05055','#c97062','#e49a73','#f1b480']]
for index,(x,base,typ) in enumerate(canopies):
 rr=random.Random(923+index); c=canopy_colors[typ];
 s.p([(x-4,base+23),(x-3,base-34),(x-27,base-49),(x-21,base-53),(x-2,base-38),(x+11,base-76),(x+16,base-76),(x+7,base-37),(x+29,base-48),(x+33,base-45),(x+5,base-27),(x+6,base+23)],'#322d42')
 blobs=[(-43,-93,41,22,1),(-22,-114,49,28,2),(16,-102,43,27,2),(-50,-73,32,27,0),(-8,-85,55,31,3),(27,-69,31,19,1),(-29,-66,41,23,2),(-15,-125,27,19,1)]
 # jagged silhouette, not duplicated rounded rectangles
 for k,(dx,dy,w,h,ci) in enumerate(blobs):
  yy=base+dy;xx=x+dx
  s.p([(xx+7,yy),(xx+w-8,yy),(xx+w-8,yy+3),(xx+w-2,yy+3),(xx+w,yy+8),(xx+w-2,yy+h-5),(xx+w-9,yy+h-5),(xx+w-9,yy+h),(xx+4,yy+h),(xx+4,yy+h-4),(xx,yy+h-4),(xx,yy+6),(xx+7,yy+6)],c[ci])
  # dappled clusters in the canopy appear as compact intentional 2-5px groups
  for j in range(3):
   px=xx+rr.randint(7,max(8,w-13));py=yy+rr.randint(5,max(6,h-6))
   s.r(px,py,rr.choice([3,5,7]),2,c[4 if j==0 else 3]);
   if j==2:s.r(px+3,py+2,2,2,c[4])
 for xx,yy in [(x-43,base-78),(x+44,base-66),(x+9,base-118)]:s.r(xx,yy,4,3,c[4])
# fences, broken stone milestones, fern pairs and shadowed shrub clumps
for j in range(35):
 x=(j*61+17)%960;y=484+(j*7%14);col=['#4b766e','#587d74','#668c78','#355b61'][j%4]
 s.r(x,y-8,2,11,col);s.r(x-5,y-3,6,2,col);s.r(x+2,y-5,5,2,col)
 if j%4==0:s.r(x-3,y-10,6,2,'#c18c75')
for i,(x,y) in enumerate([(42,484),(218,491),(382,483),(558,486),(707,489),(912,485)]):
 s.p([(x,y),(x+5,y-7),(x+12,y-7),(x+16,y-3),(x+18,y+3),(x-3,y+4)],'#334550');s.r(x+4,y-5,9,2,'#6c7770')
s.save('04_near_trees.svg')

# Art-directed roadside barrier + passing reflector poles (pattern traveling quickly)
s=Canvas(960,640)
s.r(0,502,960,9,'#182934');s.r(0,504,960,2,'#aab2a3');s.r(0,512,960,11,'#3f4b54');s.r(0,513,960,3,'#7a8c87');s.r(0,520,960,2,'#172532')
for x in range(5,960,89):
 s.r(x,505,7,29,'#1b2c39');s.r(x+1,505,2,23,'#617e7d');s.r(x+47,514,14,2,'#bb806c');s.r(x+57,515,7,1,'#dc9b79')
# scattered verge flower tufts
for i in range(53):
 x=(i*107+34)%960; y=527+(i*7%5)
 s.r(x,y-5,2,6,'#3d685e');s.r(x-3,y-3,4,2,'#4c7466')
 if i%7==0:s.r(x+1,y-6,2,2,'#d78c6e')
s.save('05_guardrail.svg')

# FLOWING ROAD: diagonal crack clusters, raised seam and sharply distinct stripe pattern
s=Canvas(960,640)
s.r(0,521,960,119,'#1b2635');s.r(0,521,960,5,'#52606b');s.r(0,529,960,3,'#2c3b4a')
s.r(0,561,960,2,'#283648')
for x in range(-150,970,123):
 s.p([(x,583),(x+74,583),(x+69,589),(x-7,589)],'#e9b78c')
 s.r(x+4,583,43,2,'#fbd9a5');s.r(x+55,587,12,2,'#c98e76')
# long asphalt crack systems following road wear rather than random confetti
for i,(x,y) in enumerate([(17,541),(132,558),(227,603),(353,541),(495,563),(611,600),(751,543),(860,562)]):
 s.p([(x,y),(x+16,y+1),(x+23,y+3),(x+41,y+3),(x+48,y+7),(x+63,y+8),(x+58,y+9),(x+42,y+8),(x+21,y+5)],'#111e2a')
 s.r(x+5,y+5,29,1,'#3b4652');s.r(x+45,y+10,20,1,'#33404b')
for i in range(335):
 x=r.randrange(960);y=r.randrange(533,637); col=['#2a3546','#394254','#344050','#344253','#273747'][i%5]
 s.r(x,y,r.choice([2,3,4,7]),1,col)
# moist bands are structured pixel stair highlights only, no blur
for x,y,w in [(20,548,34),(167,573,55),(283,537,21),(410,609,75),(630,546,40),(785,607,62)]:
 s.r(x,y,w,2,'#52444d');s.r(x+8,y+3,w//2,1,'#655259')
s.save('06_road.svg')

# Foreground rises at bottom and has distinct tall reeds / fence-side signage
s=Canvas(960,640)
s.p([(0,640),(0,625),(15,627),(28,613),(37,629),(52,616),(80,637),(113,621),(147,639),(177,620),(208,630),(230,615),(253,638),(302,621),(324,639),(353,626),(395,639),(437,625),(472,639),(498,620),(518,626),(562,614),(596,636),(634,625),(666,639),(703,617),(749,640),(782,618),(816,638),(854,626),(894,639),(927,621),(960,637),(960,640)],'#152d34')
for i in range(78):
 x=(i*73+13)%960;y=628+(i*9%11);c=['#426b5b','#507968','#77957a','#395e5e'][i%4]
 s.r(x,y-9,2,12,c);s.r(x-5,y-4,6,2,c);s.r(x+1,y-7,6,2,c)
 if i%8==0:s.r(x+3,y-11,2,3,'#d77b65')
# fast passing highway delineators clear near camera
for x in range(84,970,219):
 s.r(x+2,548,5,70,'#14232f');s.r(x,549,9,15,'#647e7d');s.r(x+1,551,6,5,'#ffe2a1');s.r(x+1,565,7,4,'#af605e')
s.save('07_foreground.svg')

# bespoke V2 car. A hot-hatch silhouette with stepped aerodynamic form and clearly sculpted volumes
s=Canvas(326,176)
# inner underbody & shadow
s.p([(7,143),(49,140),(78,140),(113,143),(221,142),(264,140),(316,144),(308,153),(19,154)],'#0b1623')
s.r(33,139,263,9,'#131c29')
# precisely designed opaque silhouette around wheel arches
s.p([(10,99),(19,91),(44,87),(58,77),(83,44),(95,34),(125,29),(176,29),(194,34),(208,46),(222,64),(234,79),(270,82),(293,88),(310,100),(316,112),(315,133),(310,142),(281,143),(279,125),(270,112),(259,108),(242,109),(229,116),(225,142),(104,142),(101,125),(92,112),(81,108),(65,110),(54,121),(51,144),(18,142),(9,133)],'#111c29')
# dark burgundy fender undershadow
s.p([(11,102),(28,94),(51,90),(85,47),(96,38),(125,33),(174,33),(191,37),(205,50),(226,80),(270,85),(294,94),(307,103),(312,114),(310,135),(298,139),(282,138),(279,124),(271,112),(259,105),(244,106),(229,114),(221,132),(220,139),(105,139),(102,124),(95,111),(80,104),(66,106),(54,118),(49,139),(19,137),(13,130)],'#5c2940')
# rich red body shaded bottom third
s.p([(13,103),(37,94),(57,90),(88,47),(99,38),(126,34),(170,34),(191,39),(220,77),(271,86),(296,95),(308,108),(310,129),(291,130),(280,112),(265,103),(240,102),(224,112),(215,128),(109,127),(102,113),(88,103),(65,102),(49,114),(42,128),(14,129)],'#a5404b')
# main mass / sculpted shoulder, lowered nose and tapered hatch
s.p([(15,101),(36,93),(56,88),(87,49),(101,40),(126,36),(169,36),(188,40),(200,49),(220,81),(273,88),(297,98),(306,106),(296,110),(279,101),(240,99),(219,105),(109,111),(89,100),(64,100),(47,112),(15,113)],'#e06a59')
# bright roof metal daylight strip with asymmetric highlights
s.p([(57,84),(88,45),(99,38),(127,34),(171,33),(191,39),(206,54),(220,79),(215,81),(200,57),(184,43),(166,38),(130,37),(105,42),(94,51),(69,86)],'#ffac7a')
s.r(123,34,41,2,'#ffd49a');s.r(176,38,12,2,'#ffd49a')
# believable hatchback greenhouse (sloping rear hatch, aggressive A-pillar)
s.p([(67,87),(94,48),(105,42),(128,39),(169,39),(185,43),(199,55),(215,82),(217,91),(63,91)],'#301f37')
# back glass narrower, deep layers and horizon gleam
s.p([(76,81),(100,50),(108,46),(135,44),(135,85),(72,85)],'#1b364b')
s.p([(83,76),(103,49),(111,47),(122,47),(105,61),(89,81)],'#588290')
s.p([(121,47),(133,46),(133,61),(114,81),(107,81)],'#31576b')
s.r(81,82,50,2,'#9c8a86')
# front side window swept rake: not a square block
s.p([(143,44),(169,44),(183,47),(196,59),(208,82),(208,85),(144,85)],'#132e45')
s.p([(150,47),(166,47),(174,49),(148,78),(147,78)],'#5b93a0')
s.p([(184,50),(194,60),(202,79),(190,78)],'#395d73')
s.r(150,83,57,2,'#879e9a');s.r(179,47,6,2,'#b0c1a7')
# clean pillars, B-pillar angled, rear spoiler is physically connected
s.p([(135,40),(145,40),(144,89),(136,89)],'#361d35')
s.p([(210,80),(217,83),(226,90),(218,91)],'#432338')
s.p([(58,85),(48,85),(36,89),(35,92),(56,90)],'#5c2940')
s.r(29,89,27,3,'#a5404b');s.r(32,87,20,1,'#f68d6a')
# body shading bands across bonnet and door, deliberate connected clusters
s.p([(228,91),(274,90),(293,95),(303,101),(300,104),(271,96),(233,96)],'#f38b6d')
s.p([(37,96),(60,89),(85,91),(102,97),(197,94),(229,91),(253,94),(282,102),(104,105),(67,97)],'#f08b6b')
s.r(111,104,102,3,'#b84d52');s.r(112,107,99,2,'#e78365')
s.p([(111,113),(212,113),(212,118),(111,119)],'#b64d52')
s.p([(105,126),(221,126),(215,139),(110,139)],'#612c3d')
s.r(117,135,95,3,'#e18b64');s.r(123,138,82,2,'#3f2637')
# door gap and intake scoop details
s.r(136,91,2,35,'#753145');s.r(138,93,2,28,'#f69771')
s.r(143,96,21,3,'#4a2a40');s.r(144,95,18,1,'#ffd399')
s.r(76,95,17,3,'#4a2a40');s.r(77,94,13,1,'#ffc692')
s.p([(219,105),(238,104),(251,107),(253,111),(224,110)],'#a84650')
s.r(228,107,12,2,'#f89974')
# detailed rake: narrow rear tail, LED stripe and dual shadow channels
s.p([(14,102),(40,95),(44,96),(40,106),(15,111)],'#51263e')
s.p([(16,103),(35,98),(39,98),(36,103),(17,107)],'#ffac75')
s.r(16,108,19,2,'#f5d2a4');s.r(14,123,19,3,'#43273b')
# front corner: bright shaped headlight, inset vents and crisp bumper
s.p([(271,89),(287,92),(306,102),(304,106),(287,104),(273,98)],'#253344')
s.p([(275,92),(289,95),(303,103),(291,101),(277,97)],'#e8f9da')
s.r(290,99,13,2,'#ffffff');s.r(304,104,3,3,'#f6c48b')
s.p([(281,118),(312,116),(313,129),(292,132),(281,129)],'#253042')
s.r(293,119,18,3,'#182433');s.r(293,122,13,2,'#738385');s.r(299,130,11,3,'#ffb879')
s.r(16,130,19,5,'#612e3d');s.r(25,137,22,4,'#452535')
# subtle light chip not bloom
for x,y in [(45,94),(65,97),(206,104),(237,95),(290,111)]:s.r(x,y,6,2,'#f99b74')
s.save('08_car_body.svg')

# wheel arch overs, mechanical slots and glossy painted fender caps
s=Canvas(326,176)
for cx in (79,260):
 s.p([(cx-35,131),(cx-34,120),(cx-29,112),(cx-20,104),(cx-7,99),(cx+8,99),(cx+21,106),(cx+29,116),(cx+34,129),(cx+30,131),(cx+27,120),(cx+17,110),(cx+5,106),(cx-10,106),(cx-22,112),(cx-29,122)],'#692f43')
 s.p([(cx-34,124),(cx-30,113),(cx-23,105),(cx-11,100),(cx+7,100),(cx+20,107),(cx+26,115),(cx+28,121),(cx+22,113),(cx+9,106),(cx-8,105),(cx-21,111),(cx-28,121)],'#ed8166')
 s.r(cx-21,105,7,2,'#ffc390');s.r(cx+13,109,7,2,'#fda27a');s.r(cx-34,138,8,4,'#4c293c');s.r(cx+26,138,8,4,'#4c293c')
s.r(116,124,103,2,'#d36859');s.r(121,131,91,3,'#462839')
s.save('10_car_fenders.svg')

# actual wheel sprite rotates; 16 directional spokes & five main swept spoke volumes
s=Canvas(68,68)
s.ellipse(34,34,32,32,'#101722');s.ellipse(34,34,29,29,'#303039')
for i in range(20):
 a=i*2*math.pi/20;x=34+int(28*math.cos(a));y=34+int(28*math.sin(a))
 s.r(x-2,y-1,5,3,'#151921' if i%2 else '#3b3a43')
s.ellipse(34,34,24,24,'#879393');s.ellipse(34,34,22,22,'#262e3b');s.ellipse(34,34,19,19,'#adb3a8');s.ellipse(34,34,17,17,'#212d3c')
for i in range(5):
 a=2*math.pi*i/5+0.23;cx=34+int(13*math.cos(a));cy=34+int(13*math.sin(a));innerx=34+int(5*math.cos(a+.08));innery=34+int(5*math.sin(a+.08));
 s.p([(innerx-2,innery-4),(innerx+3,innery-3),(cx+4,cy-3),(cx+4,cy+3),(innerx,innery+4)],'#d6ded1')
 s.r(cx-1,cy-1,4,3,'#f8ebca')
s.ellipse(34,34,6,6,'#71858a');s.ellipse(34,34,4,4,'#cfd6bf');s.ellipse(34,34,2,2,'#2a3443')
s.save('09_wheel.svg')
print('Built new V2 editable SVG layers and preserved V1 sky/mountain foundation')
