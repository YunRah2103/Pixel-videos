#!/usr/bin/env python3
from pathlib import Path
from PIL import Image
import subprocess, json, numpy as np
r=Path(__file__).resolve().parents[1]
svgs=list((r/'src'/'svg').glob('*.svg')); pngs=list((r/'assets').glob('*.png'))
assert len(svgs)==len(pngs)==12,(len(svgs),len(pngs))
for p in pngs:
 im=Image.open(p).convert('RGBA'); al=np.asarray(im)[:,:,3]
 assert np.logical_or(al==0,al==255).all(),p
 if p.stem in ('08_car_body','09_wheel','10_car_fenders'):assert im.size[0]<400
f=r/'nightfall_run_v2_10s.mp4'
info=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=width,height,r_frame_rate,nb_frames,codec_name,pix_fmt','-show_entries','format=duration','-of','json',str(f)]))
s=info['streams'][0]
assert (s['width'],s['height'],s['r_frame_rate'],int(s['nb_frames']),s['codec_name'],s['pix_fmt'])==(1080,1920,'30/1',300,'h264','yuv420p')
assert float(info['format']['duration'])==10.0
subprocess.run(['ffmpeg','-v','error','-i',str(f),'-f','null','-'],check=True)
assert (r/'before_after.png').exists() and (r/'contact_sheet_v2.png').exists()
a=json.loads((r/'qa/motion_check.json').read_text())
assert a['road_non_static_pairs']==9 and a['background_non_static_pairs']==9
print('PASS 12 original editable SVG layers, PNG palette hard-alpha, 10.00s/300f/1080x1920/H.264/30fps full-decode, road+forest real motion and review sheets')
