# Pixel Garage — NIGHTFALL RUN V2 / Artist and Tool-use Report
**Date:** 2026-10-26 | **Parent:** PR #52 / 10-second Nightfall Run V1 | **Status:** Built, full-decode tested; **human artistic approval still pending**

## Deliverables
- `nightfall_run_v2_10s.mp4`: actual 10-second 1080×1920 H.264 at 30fps and 300 frames.
- `contact_sheet_v2.png`: ten frames extracted from the actual final MP4.
- `before_after.png`: top row V1, bottom row V2 still examples (actual renders).
- `stills/`: ten high-resolution native-pixel 3× stills, both camera compositions.
- `src/svg/`: twelve editable original vector pixel-layer masters. `assets/`: exact-palette layer PNGs. `src/build_v2_art.py`, `src/render_v2.py`, `src/export_svg.sh`, `src/pixel_lock.py`: fully reproducible layered production.

## What changed **in the actual artwork**
- Preserved prior V1 twilight sky and mountain source as the foundation. Expanded the sky with stepped clouds, crystalline solar disk, cirrus clusters, distant birds and alpine-village detail.
- Redrew the mid forest with varied-height pines and staggered foliage fans, clustered cool-green highlight groups and carved dark branches. Redrew the foreground forest with irregular multi-species tree canopies, less mirrored repetition, new trunks and boulder/ferns.
- Redrew the coral sporty street-hatch car body as editable native SVG geometry: reshaped roof, raked windshield/rear hatch, sculpted door and bonnet, metallic pixel highlights, light clusters, intake and bumper, wheel arch and five-spoke wheel cels. Still a stylised side view, not a photographic model.
- Redesigned guardrail, roadside reflectors and verge planting; denser road with continuous seams, cracks, layered pixel flecks and gold lane strips.

## Animation and camera fixes
- Motion is measured in pixels **relative to the road**, rather than random footage transforms. Road displacement = `110t + 9.5t²` px, so road speed increases from 110 to 300 px/s throughout the 10 seconds.
- Different parallax multipliers: sky `.004`, upper sky `.008`, distant mountain `.045`, mountain houses `.05`, midforest `.18`, near canopy `.39`, road `1.0`, guardrail `.96`, near verge `1.25`. Nearby trees and reflectors visibly rush past while mountains move slowly.
- Wheel rotation is coupled to actual road distance divided by 31px wheel radius, drawn from 72 nearest-neighbour cels (5-degree increments). Sprung chassis uses independent roughly 1–2px movement.
- Shot 1 (frames 0–164) is a wide landscape side-tracking composition with the full car at 90.8% native scale. Shot 2 (frames 165–299) is a closer 98.5%-scale tracking side view **without cropping any of the car**. Camera change is a direct purposeful cut; no oversaturated glow, heavy transition, particles or blur.

## Actual specialist-tool use — no inflated claims
| Tool | Was run? | Real task | Command | Result / limitation | Repeatable by an AI agent? |
|---|---|---|---|---|---|
| **Inkscape** | Yes | Export twelve editable car, scenery, wheel, road SVG layers | `bash src/export_svg.sh` calls `inkscape SVG --export-type=png --export-filename=PNG` | Anti-aliased export is palette-locked into hard pixels; original SVGs remain editable | Yes |
| **Pillow + NumPy** | Yes | Native pixel compositing, correct palette, scaling and physically linked rotating-wheel cels | `python src/pixel_lock.py`, `python src/render_v2.py` | Good deterministic animation, not manual artistry | Yes |
| **ImageMagick** | Yes | Ten-frame contact sheet of **decoded MP4** and before-after comparison | `magick montage decoded/second_*.png ...` | Visual comparison, not an art generator | Yes |
| **FFmpeg** | Yes | Encoded 300 native raw frames with exact nearest-neighbour 3x H.264 scale, decoded QA captures | `python src/render_v2.py` and `ffmpeg -v error -i ... -f null -` | MP4 lossy compression minimally alters native PNG colours | Yes |
| **FFprobe** | Yes | Verified codec, resolution, frame rate, count and exact duration | `ffprobe -v error -show_entries ...` | Metadata test only | Yes |
| **OpenCV** | Yes | Numeric independent scenery/road motion analysis for every one-second sample | see `qa/motion_check.json` | Sample change proves non-static movement, not quality of feeling | Yes |
| **Pixelorama, LibreSprite, Tiled, Godot** | **No** | These are catalog options, not claimed as working tools | `qa/tool_probe.txt`; `command -v` checks | Absent; container cannot resolve `github.com` to install releases. Native PNG + SVG assets remain importable | Yes, in an equipped environment |

## Technical QA
- `qa/verify.log`: **PASS** twelve editable SVG/PNG layer pairs; no semi-transparent alpha edges; MP4 H.264 yuv420p / 1080×1920 / 30fps / 300 frames / 10.000s; complete decode without errors; generated actual contact sheet + V1/V2 comparison.
- `qa/motion_check.json`: road change in 9/9 one-second intervals; background change in 9/9 intervals. These are sample-based checks, not human playback verification.
- Sourced layers are wholly original deterministic geometry; V1's sky and mountain source inherited from the existing project. No unauthorised external assets, game sprites or copyrighted music. No soundtrack, to focus this experiment on visual improvement.

## Honest art-quality assessment
**Meaningful improvement** over V1 is visible in the varied foliage and denser world composition, improved scene depth and direct readable driving movement; V2 fixes the old unhelpful cropped close-up. However it still looks like *polished programmatically-authored retro art*, not hand-painted AAA indie pixel art. The car remains a stylised profile with some simplified panels and a soft/rounded hot-hatch silhouette; certain canopy fragments are still generated from repeatable motifs. Pixelorama/LibreSprite/Tiled were not used due to missing tools, so this is not proof those packages improved the results. Artistic approval remains an owner decision. Further improvement should focus on hand-editing silhouette/body clusters and unique tree shapes, not more visual FX.

## Rebuild (Linux + Inkscape/FFmpeg/Pillow/NumPy)
```sh
python src/build_v2_art.py
bash src/export_svg.sh
python src/render_v2.py --stills-only
python src/render_v2.py --output nightfall_run_v2_10s.mp4
ffmpeg -v error -i nightfall_run_v2_10s.mp4 -f null -
python src/verify_v2.py
```

**Safety:** New branch `exp/nightfall-run-v2-art-motion-20261026`, forked from the V1 experiment branch. No old MP4 or source overwritten. **Do not merge into main without approval.**
