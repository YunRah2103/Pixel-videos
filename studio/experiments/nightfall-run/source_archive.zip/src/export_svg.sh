#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p assets
for s in src/svg/*.svg; do n=$(basename "$s" .svg); inkscape "$s" --export-type=png --export-filename="assets/$n.png" >/dev/null 2>&1; done

python src/pixel_lock.py
