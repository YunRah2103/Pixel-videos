#!/usr/bin/env python3
"""Exact native SVG-authored palette restoration after Inkscape rasterization.
Strict color cells and hard alpha prevent any antialiasing/pseudo-pixel edge tones.
"""
from pathlib import Path
from PIL import Image
import numpy as np,re
root=Path(__file__).resolve().parents[1]
for svg in sorted((root/'src'/'svg').glob('*.svg')):
 png=root/'assets'/(svg.stem+'.png')
 a=np.array(Image.open(png).convert('RGBA'))
 colors=sorted(set(re.findall(r'fill="(#[0-9a-fA-F]{6})"',svg.read_text())))
 pal=np.array([[int(c[i:i+2],16) for i in (1,3,5)] for c in colors],dtype=np.int16)
 rgb=a[:,:,:3]
 opaque=(a[:,:,3]>=128)
 pix=rgb[opaque].astype(np.int16)
 # small bounded chunks to avoid large tensors
 nearest=np.empty(len(pix),dtype=np.int16)
 for i in range(0,len(pix),20000):
  delta=pix[i:i+20000,None,:]-pal[None,:,:]
  nearest[i:i+20000]=np.square(delta.astype(np.int32)).sum(2).argmin(axis=1)
 a[:,:,:3][opaque]=pal[nearest].astype(np.uint8)
 a[:,:,3]=opaque.astype(np.uint8)*255
 a[:,:,:3][~opaque]=0
 Image.fromarray(a,'RGBA').save(png,optimize=True)
 print(svg.stem,'authored colors:',len(colors),'opaque pixels:',opaque.sum())
