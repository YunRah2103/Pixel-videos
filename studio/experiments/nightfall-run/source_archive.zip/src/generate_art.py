#!/usr/bin/env python3
"""Original layered, pixel-aligned SVG artwork for Pixel Garage's Nightfall Run.
SVG is a genuinely editable Inkscape source. All artwork is authored here; no imported game assets.
"""
from pathlib import Path
import math,random
ROOT=Path(__file__).resolve().parents[1]
ART=ROOT/'src'/'svg';ART.mkdir(parents=True,exist_ok=True)
random.seed(26410)
class S:
 def __init__(self,w,h):
  self.w=w;self.h=h;self.a=[f'<svg xmlns="http://www.w3.org/2000/svg" xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape" width="{w}" height="{h}" viewBox="0 0 {w} {h}" shape-rendering="crispEdges">']
 def rect(self,x,y,w,h,c):
  if w>0 and h>0:self.a.append(f'<rect x="{int(x)}" y="{int(y)}" width="{int(w)}" height="{int(h)}" fill="{c}"/>')
 def poly(self,pts,c):self.a.append(f'<polygon points="'+ ' '.join(f'{int(x)},{int(y)}' for x,y in pts)+f'" fill="{c}"/>')
 def path(self,d,c,stroke=None,sw=1):self.a.append(f'<path d="{d}" fill="{c}"'+(f' stroke="{stroke}" stroke-width="{sw}"' if stroke else '')+'/>')
 def circ(self,cx,cy,r,c):self.a.append(f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="{c}"/>')
 def save(self,name):self.a.append('</svg>');(ART/name).write_text('\n'.join(self.a))

# Skyline gradient carefully limited, with 1px horizontal shimmer/pixel runs.
s=S(960,640)
strips=[(0,46,'#0e122d'),(46,90,'#1a1a3b'),(90,136,'#282046'),(136,188,'#44284f'),(188,228,'#643751'),(228,268,'#955258'),(268,307,'#be765e'),(307,366,'#dc926f'),(366,450,'#efb27c'),(450,640,'#f1ba87')]
for y1,y2,c in strips:s.rect(0,y1,960,y2-y1,c)
# deliberate bands of pixel cloud silhouettes
for ofs in [0,480]:
 s.poly([(18+ofs,110),(87+ofs,110),(87+ofs,106),(117+ofs,106),(117+ofs,112),(155+ofs,112),(155+ofs,119),(75+ofs,119),(75+ofs,117),(18+ofs,117)],'#30243f')
 s.poly([(228+ofs,182),(284+ofs,182),(284+ofs,178),(335+ofs,178),(335+ofs,181),(375+ofs,181),(375+ofs,187),(298+ofs,187),(298+ofs,185),(228+ofs,185)],'#704057')
 s.poly([(92+ofs,234),(151+ofs,234),(151+ofs,230),(196+ofs,230),(196+ofs,235),(229+ofs,235),(229+ofs,239),(92+ofs,239)],'#a76a69')
 s.rect(72+ofs,100,34,2,'#563454');s.rect(270+ofs,196,28,2,'#c27c71')
# pixel moon/sun halo pixel rings, no glow filters
for rr,c in [(51,'#cb795f'),(47,'#e9a46e'),(42,'#ffcf83'),(36,'#ffdc98')]:
 cx,cy=756,214
 for yy in range(-rr,rr+1,2):
  xw=int((rr*rr-yy*yy)**.5)
  s.rect(cx-xw,cy+yy,2*xw+1,2,c)
s.rect(721,210,20,3,'#ffe4ad');s.rect(762,229,26,2,'#ffc48a')
for k in range(68):
 x=random.randrange(960);y=random.randrange(2,157)
 s.rect(x,y,2 if k%4==0 else 1,1,'#c6a8bd' if k%3 else '#8f88b2')
s.save('01_sky.svg')

s=S(960,640)
# distant mountain system with authored ridge profile, 2 receding bands
for shift in [-40,420]:
 s.poly([(shift,355),(shift+20,337),(shift+53,337),(shift+63,317),(shift+87,317),(shift+100,298),(shift+128,287),(shift+139,276),(shift+156,276),(shift+174,297),(shift+189,293),(shift+213,310),(shift+236,306),(shift+255,322),(shift+275,317),(shift+303,343),(shift+350,326),(shift+392,352),(shift+480,352),(shift+480,505),(shift,505)],'#78617d')
 s.poly([(shift+100,298),(shift+128,287),(shift+139,276),(shift+156,276),(shift+174,297),(shift+164,294),(shift+150,289),(shift+143,287),(shift+137,294),(shift+120,302)],'#d7a4a0')
 for i,(x,y,w) in enumerate([(75,339,44),(211,317,33),(283,349,27),(369,351,25)]):s.rect(shift+x,y,w,2,'#92758b')
# distant pine skyline manual triangular tiers
for x,y,h in [(24,345,55),(63,350,64),(180,339,68),(221,352,52),(282,340,48),(340,355,70),(409,351,44),(471,337,58),(513,348,52),(600,348,74),(670,349,50),(739,346,66),(806,347,45),(890,352,72),(945,344,64)]:
 s.rect(x-2,y-h//5,4,h//5+78,'#4f5872')
 for p in range(4):
  cy=y-h+p*(h//6);ww=3+p*6
  s.poly([(x,cy-13),(x-ww,cy+7),(x+ww,cy+7)], '#48556e' if p%2 else '#52647b')
s.save('02_far_mountains.svg')

s=S(960,640)
# midground dark curved foothills at y390 and tree horizon
s.poly([(0,413),(40,406),(79,397),(127,399),(153,390),(209,400),(246,388),(282,394),(329,383),(358,390),(407,378),(447,396),(486,389),(528,403),(585,389),(630,393),(681,380),(725,393),(771,387),(820,397),(861,391),(900,398),(960,380),(960,534),(0,534)],'#34455e')
# hand-designed dense conifer trees, real trunks, tiered foliage and clusters
pine_data=[(14,419,102),(93,433,111),(142,417,129),(206,428,112),(266,420,122),(330,416,132),(395,418,112),(463,421,131),(529,419,105),(584,430,134),(653,420,119),(715,427,121),(777,418,131),(840,426,114),(919,415,125)]
for i,(x,y,h) in enumerate(pine_data):
 base=y+43;s.rect(x-3,y-h+38,6,h+65,'#1f2b3f')
 for q in range(6):
  yy=y-h+q*(h//8)+8;half=int(7+q*4.5)
  c=['#304858','#2d4355','#28465a','#25475a'][((i+q)%4)]
  s.poly([(x,yy-9),(x-half//2,yy+7),(x-half,yy+14),(x+half,yy+14),(x+half//2,yy+7)],c)
  s.rect(x-half//2+2,yy+8,6,2,'#557378' if i%2 else '#45656e')
  if q>2:s.rect(x+half//2-8,yy+5,8,2,'#5e8177')
 for q in [4,10,19]:s.rect(x+q-17,y-24-q*2,5,2,'#668479')
# thin light gaps and mist shoreline
for x in range(0,960,42):s.rect(x,437+(x%3),15,2,'#556a72')
s.save('03_mid_forest.svg')

s=S(960,640)
# nearest vegetation trees are separate from mid forest, with hand-built branches, leaf clusters
s.poly([(0,479),(25,460),(53,462),(78,451),(99,462),(124,446),(146,451),(168,461),(192,455),(218,465),(255,447),(274,456),(303,441),(346,461),(377,454),(420,464),(450,454),(496,463),(538,447),(572,458),(617,453),(659,462),(708,447),(753,464),(800,450),(849,460),(903,449),(960,462),(960,539),(0,539)],'#203c47')
# small ornate orange maple, cluster silhouette created from purposeful jagged clusters
for idx,(tx,ty,scale) in enumerate([(62,442,1),(305,436,1),(566,448,1),(834,438,1)]):
 s.rect(tx-3,ty-43,6,65,'#382f43')
 for side in [-1,1]:
  s.poly([(tx,ty-24),(tx+side*25,ty-56),(tx+side*28,ty-53),(tx+side*8,ty-18)],'#382f43')
 # step art canopy rather than circular clipart leaves
 blobs=[(-36,-72,32,16),(-18,-86,40,22),(15,-84,35,20),(-47,-51,32,18),(-7,-59,37,19),(24,-54,31,16)]
 for j,(a,b,w,h) in enumerate(blobs):
  cc=['#93434f','#a64d4e','#c46751','#d47554','#a85357','#ce7558'][(j+idx)%6]
  s.poly([(tx+a+5,ty+b),(tx+a+w-5,ty+b),(tx+a+w,ty+b+6),(tx+a+w-2,ty+b+h-3),(tx+a+w-11,ty+b+h),(tx+a+2,ty+b+h),(tx+a,ty+b+7)],cc)
  s.rect(tx+a+4,ty+b+4,8,3,'#e38c61')
  s.rect(tx+a+w-10,ty+b+h-7,8,3,'#f0a16a')
 # pixel leaf chips
 for dx,dy in [(-51,-68),(-38,-92),(5,-95),(45,-76),(18,-48),(52,-58),(-16,-37)]:s.rect(tx+dx,ty+dy,4,3,'#e5a16f')
# grass clusters, ferns and low flora
for j in range(95):
 x=(j*67+13)%960;y=478+(j%7)*5
 c=['#436359','#53736c','#667d6b','#2b5960'][j%4]
 s.rect(x,y,2,9,c);s.rect(x-3,y+4,3,2,c);s.rect(x+2,y+2,3,2,c)
 if j%5==0:s.rect(x-1,y-5,3,4,'#9b8177')
s.save('04_near_trees.svg')

s=S(960,640)
# layered highway guardrail, little reflective panels, roadside reflectors
s.rect(0,498,960,7,'#25374a');s.rect(0,500,960,2,'#91a0a0')
s.rect(0,509,960,11,'#344354');s.rect(0,511,960,3,'#a9aba7');s.rect(0,518,960,4,'#1b2c3f')
for x in range(5,960,85):
 s.rect(x,505,6,26,'#172737');s.rect(x+1,505,3,18,'#71838b')
 s.rect(x+34,511,16,2,'#bf897d')
# roadside low ground and break-up clusters
s.rect(0,526,960,6,'#253743')
for x in range(0,960,37):s.rect(x+7,525,10,2,'#55746b')
s.save('05_guardrail.svg')

s=S(960,640)
s.rect(0,520,960,120,'#202a3b');s.rect(0,520,960,4,'#a2a09a');s.rect(0,524,960,3,'#4b4955');
s.rect(0,535,960,2,'#384355');s.rect(0,596,960,3,'#544c57');
# road paint dashed separated bright pixel stair edges
for x in range(-80,960,140):
 s.poly([(x,593),(x+75,593),(x+70,598),(x-5,598)],'#c3ad93')
 s.rect(x+4,594,32,1,'#f9cf9f')
# asphalt deterministic flecks, cracks and reflections
for i in range(420):
 x=random.randrange(960);y=random.randrange(530,638)
 palette=['#293346','#31394b','#404354','#3b4150','#3d4650']
 s.rect(x,y,random.choice([2,3,5,8]),1,palette[i%5])
for x,y in [(16,547),(242,566),(488,540),(679,576),(830,553)]:
 s.poly([(x,y),(x+19,y+1),(x+26,y+3),(x+48,y+4),(x+50,y+7)],'#151f30')
 s.rect(x+8,y+7,34,1,'#3b4150')
# warmer hard-edged light patches but not gaussian bloom
for x,y,w in [(60,561,47),(194,573,62),(388,555,40),(552,568,66),(738,545,48),(889,578,61)]:
 s.rect(x,y,w,2,'#5e4a53');s.rect(x+12,y+3,w//2,1,'#72555a')
s.save('06_road.svg')

s=S(960,640)
# near bottom grasses and autumn leaves parallax - frame corners
s.poly([(0,638),(0,623),(12,624),(29,613),(43,625),(58,613),(78,630),(100,615),(113,633),(142,621),(159,636),(196,621),(225,633),(255,623),(296,639),(354,628),(389,637),(420,624),(453,639),(504,622),(525,630),(557,617),(590,637),(639,626),(687,638),(723,620),(757,628),(808,617),(845,633),(889,619),(918,635),(960,620),(960,640)],'#142b34')
for i in range(70):
 x=(i*71+11)%960;y=630+(i*3%9)
 s.rect(x,y-8,2,11,['#3c5b50','#446951','#568065','#34564c'][i%4]);
 s.rect(x-4,y-4,5,2,'#39594f');s.rect(x+2,y-6,5,2,'#5e8266')
for i in range(24):
 x=(i*193+47)%960;y=586+(i*19%53)
 s.rect(x,y,5,2,['#d77f5b','#a45457','#e6a16f'][i%3]);s.rect(x+3,y+2,2,2,'#79505b')
s.save('07_foreground.svg')

# VEHICLE: hand-authored original stylised 1990s sporty hatchback, carefully designed side profile.
s=S(324,174)
# shadow and underbody
s.poly([(13,152),(40,150),(80,149),(259,148),(311,151),(304,158),(27,158)],'#0e1825')
s.rect(35,146,255,10,'#111c2c')
# tire wells, distinct from body silhouette
for cx in (74,258):
 s.circ(cx,135,36,'#151827');s.circ(cx,135,32,'#242636');
# body silhouette with rising greenhouse, rounded head and hatch - hand placed stepped contours
s.path('M 9 101 L 13 92 L 33 88 L 51 78 L 70 57 L 88 35 L 107 26 L 155 22 L 185 24 L 199 29 L 211 45 L 224 62 L 232 80 L 269 82 L 282 86 L 298 95 L 309 103 L 313 112 L 311 132 L 306 142 L 286 147 L 274 144 L 270 129 L 265 118 L 255 110 L 244 109 L 229 113 L 220 124 L 216 143 L 111 143 L 108 128 L 101 116 L 90 109 L 72 108 L 56 116 L 46 131 L 43 144 L 17 143 L 10 138 Z','#181d2b')
# car underside and chunky body deep shaded base
s.path('M 11 104 L 31 92 L 53 83 L 78 49 L 91 34 L 107 29 L 155 25 L 182 27 L 196 32 L 210 49 L 225 73 L 229 85 L 264 86 L 283 91 L 300 101 L 306 109 L 307 132 L 298 138 L 278 140 L 274 123 L 265 111 L 254 106 L 242 106 L 228 112 L 216 130 L 213 140 L 114 140 L 111 126 L 103 114 L 89 105 L 73 104 L 56 111 L 46 128 L 42 140 L 17 139 L 12 133 Z','#8e3348')
# body volume upper / undercut, multi-ramp copper red and coral
s.poly([(12,102),(31,94),(58,89),(67,80),(222,80),(267,84),(283,91),(303,104),(304,119),(285,116),(267,102),(229,101),(214,114),(108,117),(93,104),(56,101),(40,117),(14,117)],'#d15c59')
s.poly([(15,99),(34,92),(62,81),(89,40),(108,30),(154,27),(184,29),(195,34),(220,71),(227,82),(268,86),(281,91),(296,98),(297,105),(273,96),(235,94),(216,97),(91,97),(63,92),(28,102)],'#ee7963')
# hatchback roof outline with actual volume and no square roof
s.poly([(69,76),(91,39),(107,30),(155,26),(185,28),(200,38),(218,70),(223,82),(66,82)],'#381e37')
s.poly([(89,39),(108,31),(155,29),(183,31),(196,37),(210,59),(205,58),(187,36),(150,33),(111,35),(93,45)],'#f3a17b')
s.rect(116,29,41,2,'#f8b78c')
# distinct rear and front glass with pillars and 1px glints
s.poly([(73,74),(95,44),(108,37),(135,35),(136,78),(71,78)],'#233547')
s.poly([(144,35),(182,36),(194,45),(211,73),(209,79),(145,78)],'#1a3448')
s.poly([(80,71),(98,44),(108,41),(112,42),(91,67)],'#527a85')
s.poly([(149,39),(180,39),(186,43),(162,45),(149,68)],'#447482')
s.poly([(186,44),(194,49),(205,72),(198,72)],'#395d72')
s.rect(80,73,53,3,'#536676');s.rect(146,74,59,3,'#4c6976')
# B pillar and raised hatch, slim A pillar
s.poly([(135,34),(145,34),(145,83),(137,84)],'#311d30')
s.poly([(208,68),(214,77),(220,82),(211,84)],'#351f30')
# doors separation, handles, beltline, darker basal shading
s.rect(136,83,3,43,'#a5444f');s.rect(139,86,2,39,'#eb7864')
s.poly([(50,89),(78,86),(210,87),(259,90),(275,97),(105,98)],'#f58d70')
s.rect(55,100,218,3,'#a84950');s.rect(110,117,104,2,'#e97765')
s.poly([(110,128),(114,139),(212,139),(216,127)],'#4c2b3b')
s.rect(117,136,92,3,'#f29970')
s.rect(155,91,20,3,'#442c3c');s.rect(155,91,17,1,'#f3aa7b')
s.rect(66,91,16,3,'#442c3c');s.rect(66,91,13,1,'#f3aa7b')
# rear hatch lamp stack and angular forward headlight, taillight
s.poly([(13,104),(26,98),(39,93),(42,99),(35,108),(14,111)],'#651d37')
s.poly([(14,104),(28,99),(36,97),(34,103),(17,109)],'#ff8b65')
s.rect(14,108,14,2,'#ffc58a')
s.poly([(269,89),(281,92),(299,99),(298,103),(283,102),(270,97)],'#273744')
s.poly([(272,91),(282,94),(297,100),(287,99),(274,96)],'#dffad0')
s.rect(284,97,12,2,'#ffffff')
s.rect(294,102,6,2,'#eebc8d')
# black front fascia with intake, bumper fog and tow lip
s.poly([(278,118),(302,116),(308,119),(307,129),(293,132),(281,130)],'#292a39')
s.rect(288,121,14,2,'#647178');s.rect(292,124,11,2,'#1c1e2d')
s.rect(283,134,19,4,'#442b3d');s.rect(299,130,9,3,'#f9c795')
s.rect(12,123,18,3,'#48283e');s.rect(13,133,17,5,'#4c263a')
# highlights on wheel arch/fender shapes will overlay wheels in extra layer
s.save('08_car_body.svg')

s=S(324,174)
# front/rear wheel arch contour glints, to be layered *above* rotating tire (no painted-on static wheels)
for cx in [74,258]:
 s.poly([(cx-36,130),(cx-34,115),(cx-27,106),(cx-15,99),(cx-4,97),(cx+12,100),(cx+23,107),(cx+31,118),(cx+35,130),(cx+31,128),(cx+27,117),(cx+17,109),(cx+6,105),(cx-9,105),(cx-22,112),(cx-29,121),(cx-32,132)],'#bb5057')
 s.rect(cx-26,112,7,2,'#ed8068');s.rect(cx-15,104,9,2,'#fba47c');s.rect(cx+8,105,9,2,'#ed8068')
 s.rect(cx-34,138,9,3,'#59293e');s.rect(cx+26,137,10,4,'#612d41')
# fast minimal pixel highlight through body side sill
s.rect(114,123,99,2,'#a4494e');s.rect(122,129,80,2,'#49283c')
s.save('10_car_fenders.svg')

s=S(68,68)
# A manually designed alloy wheel sprite designed for rotation. Caliper is separate body arch.
s.circ(34,34,32,'#0d101a');s.circ(34,34,29,'#252633');s.circ(34,34,26,'#131824');
# chunky tread segments and rim rings with specular glints
for k in range(16):
 a=k*math.pi/8;x=34+int(29*math.cos(a));y=34+int(29*math.sin(a))
 s.rect(x-2,y-1,5,3,'#353443' if k%2 else '#11121d')
s.circ(34,34,22,'#717a83');s.circ(34,34,20,'#1c2330');s.circ(34,34,18,'#9da9a8');s.circ(34,34,16,'#28323e')
for k in range(5):
 a=math.pi*2*k/5+0.12;bx=34+int(14*math.cos(a));by=34+int(14*math.sin(a));ex=34+int(5*math.cos(a+.15));ey=34+int(5*math.sin(a+.15))
 s.poly([(ex-3,ey-2),(ex+2,ey-3),(bx+4,by-3),(bx+3,by+4),(ex+1,ey+3)],'#cad9c8')
 s.rect(bx-1,by-1,3,3,'#eef1cf')
s.circ(34,34,6,'#73848b');s.circ(34,34,4,'#c8d4c5');s.circ(34,34,2,'#29333f')
s.save('09_wheel.svg')
print('Created',len(list(ART.glob('*.svg'))),'editable SVG artwork layers in',ART)
