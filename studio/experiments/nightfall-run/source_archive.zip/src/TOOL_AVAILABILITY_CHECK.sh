#!/bin/bash
set -u
for c in pixelorama libresprite tiled godot godot4 inkscape magick ffmpeg ffprobe xvfb-run; do
  if command -v "$c" >/dev/null 2>&1; then printf 'READY: %-14s %s\n' "$c" "$(command -v "$c")"; else printf 'MISSING: %s\n' "$c"; fi
done
