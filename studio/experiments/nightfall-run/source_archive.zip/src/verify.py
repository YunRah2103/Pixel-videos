#!/usr/bin/env python3
from pathlib import Path
from PIL import Image
import subprocess,json,hashlib,sys
root=Path(__file__).resolve().parents[1]
assert len(list((root/'src'/'svg').glob('*.svg')))==10
assert len(list((root/'assets').glob('*.png')))==10
for f in (root/'assets').glob('*.png'):
 rgba=Image.open(f).convert('RGBA')
 assert set(rgba.getchannel('A').getdata()).issubset({0,255}),f
meta=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=width,height,r_frame_rate,nb_frames,codec_name','-show_entries','format=duration','-of','json',str(root/'nightfall_run_10s.mp4')]))
s=meta['streams'][0]
assert (s['width'],s['height'],s['r_frame_rate'],int(s['nb_frames']),s['codec_name'])==(1080,1920,'30/1',300,'h264')
assert float(meta['format']['duration'])==10
subprocess.run(['ffmpeg','-v','error','-i',str(root/'nightfall_run_10s.mp4'),'-f','null','-'],check=True)
assert (root/'contact_sheet.png').exists()
print('PASS: 10 source SVGs + PNGs, hard alpha, 10s/300f/30fps/1080x1920/H264, full decode, contact sheet')
