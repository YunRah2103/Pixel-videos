#!/usr/bin/env python3
"""Layered parallax 10-second pixel film; uses actual Inkscape-exported PNG sources.
Reproduce: python src/generate_art.py; bash src/export_svg.sh; python src/render.py
"""
from PIL import Image, ImageDraw
import os, math, subprocess, argparse
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
ASSETS=ROOT/'assets'
W,H,FPS=360,640,30
layers={f.stem:Image.open(f).convert('RGBA') for f in ASSETS.glob('*.png')}
NAMES=['01_sky','02_far_mountains','03_mid_forest','04_near_trees','06_road','05_guardrail','07_foreground']
assert all(n in layers for n in NAMES),NAMES
body=layers['08_car_body'];wheel=layers['09_wheel'];fenders=layers['10_car_fenders']
# cache pixel-correct rotations; nearest-neighbour resampling, 24 hand-editable rhythm cels
wheel_cels=[wheel.rotate(i*15,resample=Image.Resampling.NEAREST,expand=False) for i in range(24)]
def tile(dst,im,offset):
 iw=im.width;off=int(offset)%iw
 for xx in range(-off,W,iw):
  dst.paste(im,(xx,0),im)
def frame(f):
 t=f/FPS
 base=Image.new('RGBA',(W,H),'#10152c')
 # Different speeds: distinct depth; slow, smoother for far elements
 speed=[3,15,26,53,149,137,183]
 layer_extra=[120,140,100,120,120,120,110]
 for name,s,orig in zip(NAMES,speed,layer_extra):
  if name=='07_foreground':continue
  im=layers[name]
  offset=orig+int(s*t)+int(6*math.sin(t*0.45))
  tile(base,im,offset)
 # car adheres to road with 1-2px suspension bounce, no motion blur
 car_x=19+int(2*math.sin(t*0.8))+int(3*math.sin(t*1.37))
 car_y=391+int(2*math.sin(t*7.0))
 # grounded wheel shadow darkens asphalt under a moving chassis
 draw=ImageDraw.Draw(base)
 draw.polygon([(car_x+20,car_y+155),(car_x+302,car_y+154),(car_x+291,car_y+161),(car_x+18,car_y+161)],fill='#101924')
 base.paste(body,(car_x,car_y),body)
 a=int(f*0.6)%24
 rw=wheel_cels[a]
 for cx in (74,258):base.paste(rw,(car_x+cx-34,car_y+135-34),rw)
 base.paste(fenders,(car_x,car_y),fenders)
 # hard pixel headlamp throw: deliberately small, no fake lens blur
 if f%9 in (0,1,2):
  draw=ImageDraw.Draw(base)
  draw.rectangle((car_x+320,car_y+103,car_x+323,car_y+105),fill='#f5f2c7')
 # tree leaves and foreground sweep, separate motion layer
 tile(base,layers['07_foreground'],110+int(183*t))
 # second purposeful composition: 2x detail camera sweeps along car, pixel-exact zoom
 if f>=185:
  p=(f-185)/(300-185)
  crop_x=int(4+150*p)
  crop_y=314+int(6*math.sin(p*math.pi))
  # mirror tiled frame vertically at base color if needed (native crop within canvas)
  crop=Image.new('RGBA',(180,320),'#202a3b');crop.paste(base,(-crop_x,-crop_y),base)
  base=crop.resize((W,H),Image.Resampling.NEAREST)
 return base.convert('RGB')

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--stills-only',action='store_true');ap.add_argument('--output',default=str(ROOT/'nightfall_run_10s.mp4'));a=ap.parse_args()
 (ROOT/'stills').mkdir(exist_ok=True)
 for f in [0,50,130,180,190,228,271,299]:
  out=frame(f).resize((1080,1920),Image.Resampling.NEAREST)
  out.save(ROOT/'stills'/f'frame_{f:03d}.png')
 print('Wrote 8 actual high resolution preview frames',flush=True)
 if a.stills_only:return
 # True streaming render: 300 native-resolution frames, FFmpeg nearest exact 3x upscale.
 cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pixel_format','rgb24','-video_size',f'{W}x{H}','-framerate','30','-i','pipe:0','-vf','scale=1080:1920:flags=neighbor,format=yuv420p','-an','-c:v','libx264','-preset','veryfast','-crf','18','-movflags','+faststart','-frames:v','300',a.output]
 print('RUN',' '.join(cmd),flush=True)
 proc=subprocess.Popen(cmd,stdin=subprocess.PIPE)
 for f in range(300):
  try:proc.stdin.write(frame(f).tobytes())
  except BrokenPipeError:break
  if f%60==0:print('frame',f,flush=True)
 proc.stdin.close();ret=proc.wait()
 if ret:raise SystemExit(f'FFmpeg exited {ret}')
 print('Wrote',a.output,flush=True)
if __name__=='__main__':main()
